function cargando(){
	if(typeof $("#cargando")[0] !== 'undefined'){
		$("#cargando").css("display", "flex");
	}
	else{
		$("body").append('<div id="cargando" style="display: flex;">Cargando...</div>');
	}
}
$(document).ready(function(){
	$.ajaxSetup({
	    headers: {
	        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
	    }
	});
	

	$("#addTransaccion").click(function(e){
		e.preventDefault();
		if(typeof $("#cargando")[0] !== 'undefined'){
			$("#cargando").css("display", "flex");
		}
		else{
			$("body").append('<div id="cargando" style="display: flex;">Cargando...</div>');
		}
		$.ajax({
			type:'GET',
			url: "/transacciones/getForm/add",
			success:function(data){
				$("#cargando").css("display", "none");
				$(".respForm").html(data);
				$('#transaccionModal').modal('show');
		   },
		   error: function(data){
		   		console.log("error");
				console.log(data);
			}
		});	
	});
	$(".editar").click(function(e){
		e.preventDefault();
		if(typeof $("#cargando")[0] !== 'undefined'){
			$("#cargando").css("display", "flex");
		}
		else{
			$("body").append('<div id="cargando" style="display: flex;">Cargando...</div>');
		}
		$.ajax({
			type:'GET',
			url: $(this).attr("href"),
			success:function(data){
				$("#cargando").css("display", "none");
				$(".respForm").html(data);
				$('#transaccionModal').modal('show');
		   },
		   error: function(data){
		   		console.log("error");
				console.log(data);
			}
		});	
	});
	$("body").on("submit", ".formGen", function(e){
		e.preventDefault();
		if(typeof $("#cargando")[0] !== 'undefined'){
			$("#cargando").css("display", "flex");
		}
		else{
			$("body").append('<div id="cargando" style="display: flex;">Cargando...</div>');
		}
		var formdata = new FormData(this);
		$.ajax({
			type:'POST',
			url: $(this).attr("action"),
			cache:false,
			processData: false,
            contentType: false,
			data: formdata,
			success:function(data){
				
				if(data.success){
					window.location.reload();
				}
				else{
					$("#infoErrorForm").css("display", "block");
					$("#infoErrorForm").html(data.mensaje);
				}
		   },
		   error: function(data){
		   		console.log("error");
				console.log(data);
			}
		});	
	});
});