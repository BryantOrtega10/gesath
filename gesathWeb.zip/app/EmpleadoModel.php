<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmpleadoModel extends Model
{
    //
}
