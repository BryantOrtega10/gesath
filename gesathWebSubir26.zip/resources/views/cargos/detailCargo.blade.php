<h2>Detalle cargo</h2>
<div class="form-group">
	<label for="nombreCargo" class="control-label">Nombre *</label>
	<input type="text" class="form-control" id="nombreCargo" name="nombreCargo" disabled value = "{{ $cargos->nombreCargo }}">
</div>